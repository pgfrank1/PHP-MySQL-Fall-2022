<?php

    define('HOME_PAGE', 'Project 3 - Home');
    define('VIEW_PROFILE', 'Project 3 - View Profile');
    define('LOG_EXERCISE', 'Project 3 - Log Exercise');
    define('EDIT_PROFILE', 'Project 3 - Edit Profile');
    define('CREATE_USER', 'Project 3 - Create New User');
    define('USER_LOGIN', 'Project 3 - Login');
    define('DELETE_POST', 'Project 3 - Delete Post');
?>