<?php

const HOME_PAGE = 'The Game';
const INDEX_PAGE = 'Welcome to Project 4';
const ADMIN_LOGIN = 'Admin Login';
const ADMIN_PAGE = 'Administrative Page';
