<nav class="navbar navbar-expand-lg bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand text-light" href="index.php">Project 2</a>
        <a href="createAPost.php">
            <input class="btn bg-primary text-light" type="button" value="Create a post">
        </a>
    </div>
</nav>