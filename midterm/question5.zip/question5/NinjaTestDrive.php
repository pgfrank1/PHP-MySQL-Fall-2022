<?php
require_once("Ninja.php");
$test = new Ninja();
$test->name = "Patrick";
$test->email = "pgfrank@madisoncollege.edu";
$test->JumpingSpinKick();