<?php

class Person
{
    public $name;
    public $email;

}