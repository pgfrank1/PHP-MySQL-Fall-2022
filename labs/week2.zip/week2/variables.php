<?php
    // Declare 2 variables and output them
    $numberOne = 1;
    $numberTwo = 2;
    echo $numberOne;
    echo $numberTwo;

    // Create a name variable and say hello with it
    $myName = "Patrick";
    echo "<br>Hello $myName";

    // Define a constant and output it
    define("GRAVITY_ACCELERATION", 9.81);
    echo "<br>" . GRAVITY_ACCELERATION;
?>