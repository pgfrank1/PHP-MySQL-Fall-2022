<?php 
    // Assign first and last name variables and concatenate them
    $firstName = "Patrick";
    $lastName = "Frank";
    echo $firstName . " " . $lastName;

    // Use String Interpolation
    echo "<br>$lastName, $firstName";

    // Change the last name
    $lastName = "O'Connor";
    echo "<br>$firstName $lastName";
?>